We introduce an email dataset, a subset of the ENRON data (Cohen, 2009), with tags about interpersonal communication traits, namely, Formality, Politeness, and Frustration. The dataset provides the text, user information, as well as the network information for email exchanges between Enron employees. 

The ENRON-FFP dataset contains 960 emails and their associated Formality, Politeness and Frustration scores given by 10 annotators. 


If you use the ENRON-FFP dataset, please cite our paper 

@inproceedings{khosla2018aff2vec,
  title={Aff2Vec: Affect--Enriched Distributional Word Representations},
  author={{Khosla}, S. and {Chhaya}, N. and {Chawla}, K.},
  booktitle={Proceedings of COLING 2018, the 27th International Conference on Computational Linguistics},
  pages={2204--2218},
  year={2018}
}

and the complete ENRON dataset 

@article{cohen2009enron,
  title={Enron email dataset},
  author={Cohen, William W},
  year={2009}
}.

Affect-enriched embeddings introduced in the paper are available here: https://bit.ly/2HGohsO
